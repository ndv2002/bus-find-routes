/* fonts */
export const FontFamily = {
  text14Bold: "Lexend_bold",
  lexendSemibold: "Lexend_semibold",
  lexendRegular: "Lexend_regular",
  lexendMedium: "Lexend_medium",
};
/* font sizes */
export const FontSize = {
  text14Bold_size: 14,
};
/* Colors */
export const Color = {
  backgroundColorsBackgroundMain: "#fff",
  backgroundColorsBackgroundLighter: "#fafafa",
  gray_100: "#1f1f1f",
  brandColorsNightPurple: "#1a1528",
  textColorsLight: "#404040",
  backgroundColorsBackgroundLight: "#f5f5f5",
};
/* Paddings */
export const Padding = {
  p_5xl: 24,
  p_xl: 20,
  p_29xl: 48,
  p_3xs: 10,
  p_17xl: 36,
};
/* border radiuses */
export const Border = {
  br_base: 16,
  br_9980xl: 9999,
};
